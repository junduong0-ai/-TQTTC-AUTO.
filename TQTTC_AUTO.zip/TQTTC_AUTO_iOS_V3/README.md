# TQTTC AUTO iOS — V3

Prototype SwiftUI cho iPhone. Có giao diện tối giản, 4 công tắc lưu trạng thái, nút Dừng tất cả và trang hướng dẫn Switch Control.

> Lưu ý quan trọng: các công tắc hiện chỉ lưu lựa chọn trong app. iOS không cho app thông thường tự đọc màn hình hoặc tự điều khiển game khác. Đây chưa phải bot tự động thao tác trong game.

## Tạo IPA bằng iPhone + GitHub Actions

1. Tạo tài khoản/đăng nhập GitHub và tạo repository mới, ví dụ `TQTTC-AUTO`.
2. Giải nén ZIP này. Tải toàn bộ nội dung bên trong thư mục `TQTTC_AUTO_iOS_V3` lên repository (giữ nguyên thư mục `.github/workflows`).
3. Mở repository → tab **Actions** → chọn **Build TQTTC AUTO IPA** → **Run workflow**.
4. Chờ workflow chạy xong, mở lần chạy thành công ở cuối trang.
5. Trong mục **Artifacts**, tải `TQTTC-AUTO-unsigned-IPA` về iPhone và giải nén nếu iOS tải về dưới dạng ZIP.
6. Mở ESign, nhập file `TQTTC_AUTO_unsigned.ipa`, chọn chứng chỉ và provisioning profile phù hợp rồi ký/cài.

Nếu GitHub không hiện workflow, vào **Actions** và bật workflow cho repository. Khi upload file lên GitHub, nhớ bật hiển thị file ẩn để thư mục `.github` được đưa lên; nếu không, tạo thủ công đường dẫn `.github/workflows/build-ipa.yml` và dán nội dung workflow.

## Yêu cầu ký

- Bundle ID của app: `vn.tqttc.auto`.
- Provisioning profile phải cho phép Bundle ID này (hoặc wildcard tương thích).
- IPA được tạo ở dạng chưa ký; ESign sẽ ký lại bằng chứng chỉ/profile của bạn.

## Chức năng

- AUTO QUEST, AUTO BATTLE, AUTO REWARD, AUTO CONTINUE: công tắc giao diện, lưu trạng thái bằng UserDefaults.
- STOP ALL: tắt toàn bộ công tắc.
- Hướng dẫn Switch Control cơ bản.

## Cấu trúc

- `project.yml`: cấu hình XcodeGen.
- `.github/workflows/build-ipa.yml`: tự build IPA bằng máy macOS của GitHub Actions.
- `TQTTC_AUTO/`: mã nguồn SwiftUI.
