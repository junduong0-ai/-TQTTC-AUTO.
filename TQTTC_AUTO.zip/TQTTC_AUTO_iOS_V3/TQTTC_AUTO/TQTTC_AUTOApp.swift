import SwiftUI

@main
struct TQTTC_AUTOApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
