import SwiftUI

@MainActor
final class AutoSettings: ObservableObject {
    @Published var quest = UserDefaults.standard.bool(forKey: "auto.quest") {
        didSet { UserDefaults.standard.set(quest, forKey: "auto.quest") }
    }
    @Published var battle = UserDefaults.standard.bool(forKey: "auto.battle") {
        didSet { UserDefaults.standard.set(battle, forKey: "auto.battle") }
    }
    @Published var reward = UserDefaults.standard.bool(forKey: "auto.reward") {
        didSet { UserDefaults.standard.set(reward, forKey: "auto.reward") }
    }
    @Published var continueStage = UserDefaults.standard.bool(forKey: "auto.continue") {
        didSet { UserDefaults.standard.set(continueStage, forKey: "auto.continue") }
    }

    var anyEnabled: Bool { quest || battle || reward || continueStage }

    func stopAll() {
        quest = false
        battle = false
        reward = false
        continueStage = false
    }
}

struct ContentView: View {
    @StateObject private var settings = AutoSettings()

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.055, green: 0.065, blue: 0.09).ignoresSafeArea()
                VStack(spacing: 20) {
                    VStack(spacing: 6) {
                        Text("TQTTC AUTO")
                            .font(.system(size: 29, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Text("TRỢ LÝ TÁC VỤ")
                            .font(.system(size: 11, weight: .semibold))
                            .tracking(2.2)
                            .foregroundStyle(.white.opacity(0.5))
                    }
                    .padding(.top, 16)

                    VStack(spacing: 0) {
                        ToggleRow(title: "AUTO QUEST", subtitle: "Theo dõi nhiệm vụ tân thủ", isOn: $settings.quest)
                        rowDivider
                        ToggleRow(title: "AUTO BATTLE", subtitle: "Lưu tùy chọn hỗ trợ vượt ải", isOn: $settings.battle)
                        rowDivider
                        ToggleRow(title: "AUTO REWARD", subtitle: "Theo dõi phần thưởng cần nhận", isOn: $settings.reward)
                        rowDivider
                        ToggleRow(title: "AUTO CONTINUE", subtitle: "Nhắc bước tiếp theo sau mỗi ải", isOn: $settings.continueStage)
                    }
                    .padding(.horizontal, 16)
                    .background(Color.white.opacity(0.055))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.08), lineWidth: 1))

                    HStack(spacing: 10) {
                        Circle().fill(settings.anyEnabled ? Color.green : Color.gray).frame(width: 9, height: 9)
                        Text(settings.anyEnabled ? "ĐÃ BẬT TÙY CHỌN" : "ĐANG CHỜ")
                            .font(.system(size: 12, weight: .semibold))
                            .tracking(0.8)
                            .foregroundStyle(.white.opacity(0.75))
                        Spacer()
                    }

                    Button(action: settings.stopAll) {
                        Label("DỪNG TẤT CẢ", systemImage: "stop.fill")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 17)
                            .background(Color.red.opacity(0.88))
                            .clipShape(RoundedRectangle(cornerRadius: 15))
                    }

                    NavigationLink {
                        GuideView()
                    } label: {
                        Label("HƯỚNG DẪN HỖ TRỢ TRÊN IPHONE", systemImage: "iphone.gen3")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }

                    Text("Các công tắc hiện chỉ lưu tùy chọn trong app; chưa điều khiển game.")
                        .font(.system(size: 11))
                        .foregroundStyle(.white.opacity(0.42))
                        .multilineTextAlignment(.center)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 14)
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
    }

    private var rowDivider: some View {
        Divider().overlay(.white.opacity(0.08))
    }
}

private struct ToggleRow: View {
    let title: String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.system(size: 14, weight: .bold, design: .rounded))
                    .tracking(0.7).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 11)).foregroundStyle(.white.opacity(0.48))
            }
            Spacer(minLength: 8)
            Toggle(title, isOn: $isOn).labelsHidden().tint(.green)
        }
        .padding(.vertical, 16)
    }
}

private struct GuideView: View {
    var body: some View {
        ZStack {
            Color(red: 0.055, green: 0.065, blue: 0.09).ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Hỗ trợ trên iPhone")
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)

                    GuideCard(number: "01", title: "Mở Trợ năng", detail: "Vào Cài đặt > Trợ năng. Tìm Switch Control (Điều khiển công tắc).")
                    GuideCard(number: "02", title: "Thiết lập công tắc", detail: "Chỉ cấu hình thao tác mà iOS hỗ trợ và thử trước trên màn hình không quan trọng.")
                    GuideCard(number: "03", title: "Dùng trong game có kiểm soát", detail: "Chỉ dùng chuỗi thao tác đơn giản, có thể dừng ngay. Không dùng để vượt xác minh, né chống gian lận hoặc khai thác lỗi.")
                    GuideCard(number: "04", title: "Tắt khi hoàn tất", detail: "Tắt Switch Control sau khi dùng để tránh iPhone tự chọn nhầm nút.")

                    Text("Giới hạn quan trọng")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Ứng dụng này không thể đọc giao diện hoặc tự bấm trong Tam Quốc Tứ Thời Ca. iOS cô lập ứng dụng với nhau. Các tính năng Auto trên màn hình chính hiện là công tắc lưu cấu hình, không phải bot đang chạy.")
                        .font(.system(size: 13))
                        .foregroundStyle(.white.opacity(0.7))
                        .padding(15)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.orange.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding(20)
            }
        }
        .navigationTitle("Hướng dẫn")
        .navigationBarTitleDisplayMode(.inline)
        .preferredColorScheme(.dark)
    }
}

private struct GuideCard: View {
    let number: String
    let title: String
    let detail: String

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Text(number)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(.green)
                .padding(9)
                .background(Color.green.opacity(0.13))
                .clipShape(RoundedRectangle(cornerRadius: 9))
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
                Text(detail).font(.system(size: 12)).foregroundStyle(.white.opacity(0.58))
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.055))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}
